#! /usr/bin/env python

print "\nThis is the example program running (writing to example.log)\n"

f = open('example.log', 'a')
f.write("\nThis is the example program running (writing to example.log)\n")
f.close()
