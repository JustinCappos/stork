#! /usr/bin/env python
"""
Stork Project (http://www.cs.arizona.edu/stork/)
Module: arizonacrypt
Description:  Provides cryptographic utility functions and commands

Notes:
Stork's cryptographic features rely on communication with openssl.

The functions used here either take string lists or filenames as 
arguments.  Which it takes can be determined by the function suffix "sl" 
or "fn".  There are also routines sl_to_fn and fn_to_sl to convert between 
the two formats.


"""


# This sets up the options for arizonaconfig
#           [option, long option,  variable,   action,  data,     default,  metavar,    description]#
"""arizonaconfig
   options=[["",     "--keytype",  "keytype",  "store", "string", "rsa",    "KEYTYPE",  "Use this technique to sign files (default is rsa)"],
            ["",     "--keygen",   "keygen",   "store", "string", "genrsa", "GENTYPE",  "Use this option to openssl to generate your public/private keypair (default is genrsa)"],
             ["",     "--xmlsignaturedtd",     "xmlsigndtd",  "store",       "string", "arizonacrypt_signature.dtd", "FILENAME",  "The DTD file for signatures"],
            ["",     "--hashtype", "hashtype", "store", "string", "-sha1",  "HASHTYPE", "Use this algorithm to generate hashes (default is -sha1)"]]
   includes=[]
"""

import sys
import re
import os.path
import tempfile
import shutil
import arizonareport
import arizonaconfig
import arizonageneral

# add for XML signature routines
import arizonaxml
import time


# For some reason, openssl can't verify hex signatures...   :(
# I use this as a workaround in the signedhash routines...
import binascii






def valid_sl(stringlist):
   """
   <Purpose>
      This returns True if stringlist is a list of strings or False if it  
      is not.

   <Arguments>
      stringlist:
          The variable to be checked.

   <Exceptions>
      None

   <Side Effects>
      None

   <Returns>
      True or False (see above)
   """

   try:
      arizonageneral.check_type_stringlist(stringlist, "stringlist", "valid_sl")
      return True
   except TypeError:
      return False

   



def sl_to_fn(stringlist):
   """
   <Purpose>
      This dumps a string list to a tempfile and returns the filename...
      The calling routine *must* remove the tempfile when finished...

   <Arguments>
      stringlist:
            The list that should be dumped to a file.   This must be a
            list of strings.   If it is invalid, it will throw TypeError

   <Exceptions>
      TypeError if stringlist is not a list of strings...

   <Side Effects>
      This function creates the file whose name it returns.

   <Returns>
      The name of the temp file it creates.
   """

   if not valid_sl(stringlist):
      raise TypeError, "Invalid stringlist in sl_to_fn"
      
   # Get a new temp file
   (thisfile,thisfilename) = tempfile.mkstemp(suffix=".sl_to_fn.temp")

   # Write the stringlist into the file
   for item in stringlist:
      os.write(thisfile, item.rstrip('\r\n')+'\n')

   # Close the fd
   os.close(thisfile)

   # Return the file name
   return thisfilename






def fn_to_sl(filename):
   """
   <Purpose>
      This takes a file and reads the contents as a list of strings.
      It returns the list of strings.   This function does not remove
      the file.

   <Arguments>
      filename:
            This is the filename containing the string list.  If it is 
            invalid, it will throw IOError or OSError and set errno, etc. 
            appropriately

   <Exceptions>
      IOError or OSError if filename has errors...   There is basically
      no checking in this routine.   The routines in os should correctly
      throw exceptions...

   <Side Effects>
      None

   <Returns>
      The stringlist containing the file data
   """

   # This should throw an exception if there are problems.   The outer program
   # will catch it...
   fileobj = open(filename, "r")
   
   sl = arizonageneral.stream_to_sl(fileobj)
   fileobj.close()
   return sl





def get_genkey_type(type_of_genkey=None):
   """
   <Purpose>
      This returns the default genkey if given None or the given string 
      otherwise.   

   <Arguments>
      type_of_genkey:
            This is the (possibly) user specified key type.  If the value 
            is not specified then the default is used.

   <Exceptions>
      TypeError if type_of_genkey is not a string, etc.

   <Side Effects>
      None

   <Returns>
      A string containing the genkey function that should be used.
   """


   # Did they specify the argument?
   if type_of_genkey == None:
      ret_val = arizonaconfig.get_option("keygen")
   else:
      ret_val = type_of_genkey

   try:
      return "" + ret_val
   except TypeError:
      raise TypeError, "Invalid genkey type in get_genkey_type"





def get_key_type(type_of_key=None):
   """
   <Purpose>
      This returns the default key type if given None or the given string 
      otherwise.   

   <Arguments>
      type_of_key:
            This is the (possibly) user specified key type.  If the value 
            is not specified then the default is used.

   <Exceptions>
      TypeError if type_of_key is not a string, etc.

   <Side Effects>
      None

   <Returns>
      A string containing the key function that should be used.
   """


   # Did they specify the argument?
   if type_of_key == None:
      ret_val = arizonaconfig.get_option("keytype")
   else:
      ret_val = type_of_key

   try:
      return "" + ret_val
   except TypeError:
      raise TypeError, "Invalid key type in get_key_type"





def get_hash_type(type_of_hash=None):
   """
   <Purpose>
      This returns the default hash if given None or the given string 
      otherwise.   If necessary it prepends "-" to the string.

   <Arguments>
      type_of_hash:
            This is the (possibly) user specified hash type.  If the value 
            is not specified then the default is used.

   <Exceptions>
      TypeError if type_of_hash is not a string, etc.

   <Side Effects>
      None

   <Returns>
      A string containing the hash function that should be used.
   """


   # Did they specify the argument?
   if type_of_hash == None:
      ret_val = arizonaconfig.get_option("hashtype")
   else:
      ret_val = type_of_hash
   try:
      if not ret_val.startswith('-'):
         ret_val = '-'+ret_val
      return "" + ret_val
   except (TypeError, AttributeError):
      raise TypeError, "Invalid hash type in get_hash_type"





def generate_privatekey_sl(type_of_key=None):
   """
   <Purpose>
      This creates a privatekey and returns the sl.

   <Arguments>
      type_of_key:
            This is the kind of key that should be generated (genrsa, 
            gendsa, etc.).   If the value is not specified then the 
            default is used.

   <Exceptions>
      As thrown by stream_to_sl and os.popen3 (TypeError, ValueError, 
      IOError).  ValueError is raised if the type_of_key is invalid

   <Side Effects>
      None

   <Returns>
      A string list with the privatekey.   If the type_of_key is not valid
      the routine throws TypeError
   """

   # If they specified the type of key then listen, otherwise use the default
   ( junk_in, the_out, junk_err) = os.popen3("openssl "+get_genkey_type(type_of_key))

   # close extraneous streams
   junk_in.close()
   junk_err.close()

   # get the private key from stdout
   privatekey_sl = arizonageneral.stream_to_sl(the_out)
   the_out.close()
      
   # Didn't return a key
   assert (privatekey_sl != [])

   return privatekey_sl





def generate_privatekey_fn(filename,type_of_key=None):
   """
   <Purpose>
      This creates a file that contains a privatekey.

   <Arguments>
      filename:
            This creates a file with this name
      type_of_key:
            This is the kind of key that should be generated (genrsa, 
            gendsa, etc.).   If the value is not specified then the 
            default is used.

   <Exceptions>
      As thrown by generate_privatekey_sl, sl_to_fn, and shutil.move
      (TypeError, ValueError, IOError).

   <Side Effects>
      Creates the file "filename"

   <Returns>
      None
   """

   assert(isinstance(filename,str))

   # Check if the dest is a dir
   if os.path.isdir(filename):
      raise IOError, (21, "Is a directory")

   # Create a sl with the private key
   privatekey_sl = generate_privatekey_sl(type_of_key)

   # If this fails, then raise an exception
   assert(privatekey_sl != [])

   # Dump it to disk
   privatekey_temp_fn = sl_to_fn(privatekey_sl)

   # Move it to the correct filename
   try:
      shutil.move(privatekey_temp_fn,filename)
   except (IOError, OSError):
      # Clean up when an error occurs
      os.remove(privatekey_temp_fn)
      raise

   return None

      



def extract_publickey_sl_from_privatekey_fn(privatekey_fn,type_of_key=None):
   """
   <Purpose>
      This gets a sl which contains the publickey from a given privatekey 
      filename

   <Arguments>
      privatekey_fn:
            The filename which contains the private key
      type_of_key:
            This is the type of key (rsa, dsa, etc.).   If the value is 
            not specified then the default is used.

   <Exceptions>
      TypeError is privatekey_fn or type_of_key are invalid.   IOError if 
      the privatekey_fn is invalid or unreadable, etc.

   <Side Effects>
      None

   <Returns>
      The sl that contains the public key
   """

   # Does the file exist?
   if not arizonageneral.valid_fn(privatekey_fn):
      raise IOError, (2, "No such file or directory")

   # If they specified the type of key then listen, otherwise use the default
   ( junk_in, the_out, the_err) = os.popen3("openssl "+get_key_type(type_of_key)+" -in "+privatekey_fn+" -pubout")

   # close extraneous streams
   junk_in.close()

   # get the error output
   err_sl = arizonageneral.stream_to_sl(the_err)
   the_err.close()

   # Check to see if an error we were expecting occured
   for line in err_sl:
      if line == "unable to load Private Key":
         raise TypeError, "Invalid private key file in extract_publickey_sl_from_privatekey_fn"
         

   # get the public key from the stream
   publickey_sl = arizonageneral.stream_to_sl(the_out)
   the_out.close()

   # Return the publickey
   assert(publickey_sl != [])
   return publickey_sl





def extract_publickey_sl_from_privatekey_sl(privatekey_sl,type_of_key=None):
   """
   <Purpose>
      This gets a sl which contains the publickey from a given privatekey 
      sl

   <Arguments>
      privatekey_sl:
            The sl which contains the private key
      type_of_key:
            This is the type of key (rsa, dsa, etc.).   If the value is 
            not specified or a string then the default is used.

   <Exceptions>
      TypeError is privatekey_sl or type_of_key are invalid and any 
      exceptions raised by extract_publickey_sl_from_privatekey_fn

   <Side Effects>
      None

   <Returns>
      None
   """

   temp_privatekey_fn = sl_to_fn(privatekey_sl)
   

   # Try to get the publickey our of the privatekey and re-raise the exception
   # if it fails (after cleaning up)
   try: 
      publickey_sl = extract_publickey_sl_from_privatekey_fn(temp_privatekey_fn,type_of_key)
   finally:
      os.remove(temp_privatekey_fn)

   # return the publickey
   assert(publickey_sl != [])
   return publickey_sl





def publickey_fn_to_sl(filename, key_type=None):
   """
   <Purpose>
      This returns a tuple containing a boolean which specifies whether or
      not the file is valid and a stringlist of the publickey stored in 
      the filename.   

   <Arguments>
      filename:
            This the file name that may contain a public key
      key_type:
            The type of public key that will be fetched.   If it is None, 
            then the default is used

   <Exceptions>
      None

   <Side Effects>
      None

   <Returns>
      A tuple containing a boolean indicating success or failure and 
      string list with the publickey 
   """

   try:
      # Read in a public key in rsa format...
      ( junk_in, the_out, junk_err) = os.popen3("openssl "+get_key_type(key_type)+" -pubin -in "+filename)
   except (TypeError, IOError, OSError):
      return (False, [])

   # Close input and error streams
   junk_in.close()
   junk_err.close()

   try:
      # Return the string list that results.   The openssl stream will be 
      # empty if the file is invalid and thus this will return []...
      ret_sl = arizonageneral.stream_to_sl(the_out)
   except (TypeError,IOError):
      return (False, [])

   the_out.close()

   if ret_sl == []:
      return (False, [])

   return (True, ret_sl)







def valid_publickey_sl(publickey_sl, key_type=None):
   """
   <Purpose>
      This returns True or False which specifies whether or not the string
      list contains a valid publickey.

   <Arguments>
      publickey_sl:
            This the string list that may contain a public key
      key_type:
            The type of public key that will be fetched.   If it is None, 
            then the default is used

   <Exceptions>
      None

   <Side Effects>
      None

   <Returns>
      A boolean indicating if the publickey is valid or not
   """

   # Ensure the sl is valid
   assert(valid_sl(publickey_sl))

   # Dump it to a file
   temp_publickey_fn = sl_to_fn(publickey_sl)
 
   # Try to get the file into a sl
   (ret_val, junk) =  publickey_fn_to_sl(temp_publickey_fn, key_type)
   
   # remove the tempfile
   os.remove(temp_publickey_fn)

   return ret_val





##
# Create the hash of the metadata
# Either reads metadata as arg or from stdin
# expects null or filename STRING
# returns hash
def get_metadata_hash(filename, hash_type=None):
    print "get_metadata_hash is totally bogus"
    sys.exit(1)
    import os
    

    #print "[DEBUG] filename=" + str(filename), #DEBUG !!!!!!!!!!!!!!!!!!!
    #print "[DEBUG] hash_type=" + str(hash_type), #DEBUG !!!!!!!!!!!!!!!!!!!

    meta = get_metadata(filename)
    if meta == None:
        arizonareport.send_error(4, "[DEBUG] get_metadata_hash: No hash, using file contents")
        return get_fn_hash(filename)
        #fh = open(filename)
        #contentsList = fh.readlines()
        #meta = contentsList[0]
        #for i in contentsList[1:]:
        #    meta += i
        #fh.close()
        #arizonareport.send_error(4, "[DEBUG] get_metadata_hash: Done reading file contents")

    # Generate the hash
    ( junk_in, the_out, the_err ) = os.popen3("echo \""+meta+"\" | openssl dgst "+get_hash_type(hash_type))

    # Close the input stream
    junk_in.close()

    # Grab the data the command spits on stdout
    out_data = arizonageneral.stream_to_sl(the_out)
    the_out.close()
    
    # Grab the data the command spits on stderr
    err_data = arizonageneral.stream_to_sl(the_err)
    the_err.close()

    # If something was put to stderr then fail
    if not err_data == []:
        raise IOError, (22, "Invalid argument: Unable to generate hash in get_fn_hash")

    assert(out_data != [])

    arizonareport.send_error(4, "[DEBUG] get_metadata_hash: Hash = " + str(out_data[0]))

    # return the relevant part of the hash
    return out_data[0]





def get_metadata(filename):
    import os
    import storkpackage

    # TODO FIXME NEEDS WORK BROKEN.. this code MUST NOT be rpm specific
    #fields = ['%{NAME}', '%{VERSION}', '%{RELEASE}', '%{SIZE}']
    info = storkpackage.get_package_info(filename)
    if info == None:
       return None

    meta = "Package:\n"
    # append the file hash
    for data in info:
    	meta += data + '|'  
    meta += get_fn_hash(filename, "-sha1")

    # get what requires
    requires = storkpackage.get_packages_require([filename])
    # append what requires
    meta += "\nRequires:\n"
    meta += '|' + '|'.join(requires)
    
    # get what provides
    provides = storkpackage.get_packages_provide([filename])   
 
    # append what provides
    meta += "\nProvides:\n"
    meta += '|' + '|'.join(provides)

    # get what files are in the package
    files = storkpackage.get_packages_files([filename])
    shortname = ''
    for name in files:
	shortname += "|" + os.path.basename(name)
    
    # append the filenames
    meta += "\nFiles:\n"	
    meta += shortname

    return meta
 
 
 
  

def get_fn_hash(filename,hash_type=None):
   """
   <Purpose>
      This returns the hash of a file's contents given the name

   <Arguments>
      filename:
            This the name of the file to generate a hash for
      hash_type:
            The hash function that should be used.   If it is None, then 
            the default is used

   <Exceptions>
      IOError will be thrown when the file is invalid or another file 
      related error occurs.   TypeError may also be thrown if hash_type is
      invalid.

   <Side Effects>
      None

   <Returns>
      A string containing the file's hash
   """

   # Check the file name
   if not arizonageneral.valid_fn(filename):
      raise IOError, (2, "Invalid file in get_fn_hash: " + str(filename))

   # Generate the hash
   ( junk_in, the_out, the_err ) = os.popen3("openssl dgst " + get_hash_type(hash_type) + " " + filename)

   # Close the input stream
   junk_in.close()

   # Grab the data the command spits on stdout
   out_data = arizonageneral.stream_to_sl(the_out)
   the_out.close()

   # Grab the data the command spits on stderr
   err_data = arizonageneral.stream_to_sl(the_err)
   the_err.close()

   # If something was put to stderr then fail
   if not err_data == []:
      raise IOError, (22, "Invalid argument: Unable to generate hash in get_fn_hash")

   assert(out_data != [])

   # return the relevant part of the hash
   return out_data[0].split()[1]





def publickey_sl_to_fnstring(publickey_sl):
   """
   <Purpose>
      This removes unnecessary information from a publickey_sl and returns
      only a string containing the characters that form the publickey.   
      Leading and trailing '=' are removed and all '/' are replaced by '_'
      to allow this string to be used as a filename.   The publickey_sl is
      not checked for validity.

   <Arguments>
      publickey_sl:
            This is the stringlist containing the publickey

   <Exceptions>
      TypeError will be thrown

   <Side Effects>
      None

   <Returns>
      A string containing the publickey in the above format
   """

   # Strip out the lines that start with -----
   new_publickey_sl = []
   for item in publickey_sl:
      if not item.startswith('-----'):
         new_publickey_sl.append(item)

   # Make it one string
   publickey_string = "".join(new_publickey_sl)

   # Replace '/' with '_' and remove '='
   publickey_string = re.sub('/','_',publickey_string)
   publickey_string = publickey_string.strip('=')

   return publickey_string





def fnstring_to_publickey_sl(fnstring):
   """
   <Purpose>
      This generates a publickey_sl given a fnstring as would be generated
      by publickey_sl_to_fnstring.   While the number of '=' in the 
      original publickey cannot be known, it seems to always be 2, so we 
      append appropriately to the correct place in the stringlist.   See 
      publickey_sl_to_fnstring for more information about the 
      transformation.

   <Arguments>
      fnstring:
            This is the string to be converted to a publickey

   <Exceptions>
      TypeError will be thrown if fnstring seems invalid

   <Side Effects>
      None

   <Returns>
      A stringlist containing the publickey.   This must be checked 
      elsewhere for validity.
   """

   # if the caller gave us a pathname, then we only want to filename part
   (path, fnstring) = os.path.split(fnstring)

   # get just the pub key in the filename, not the whole filename itself
   tmppub  = fnstring.split(".")
   if len(tmppub) > 1:
       fnstring= tmppub[1]; 
   
   # Replace _ by / and append ==
   publickey_string = re.sub('_','/',fnstring)+"=="

   # Append the leading line
   publickey_sl = ['-----BEGIN PUBLIC KEY-----']

   # we will split the key into half (so the lines aren't so long).   openssl 
   # doesn't seem to care whether we do this or not
   publickey_string_mid = len(publickey_string) / 2
   publickey_sl.append(publickey_string[:publickey_string_mid])
   publickey_sl.append(publickey_string[publickey_string_mid:])

   # Now append the trailing line
   publickey_sl.append('-----END PUBLIC KEY-----')

   return publickey_sl





def get_fn_signedhash_using_privatekey_fn(filename, privatekey_fn, type_of_hash=None):
   """
   <Purpose>
      This takes a file, a private key, and a hash type and generates a 
      hash of the file signed by the private key.  The type of private key
      is not taken as an argument because it is not accepted as an 
      argument by openssl.

   <Arguments>
      filename:
            The file which will have a hash, etc. generated for it.
      privatekey_fn:
            The filename which contains the private key
      type_of_hash:
            This is the type of hash (sha1, etc.).   If the value is not 
            specified then the default is used.

   <Exceptions>
      TypeError is privatekey_fn or type_of_key are invalid.   IOError if 
      the privatekey_fn or filename is invalid or unreadable, etc.

   <Side Effects>
      None

   <Returns>
      A string containing the signed hash of the file.   This is generated 
      using the binascii routine, since the original hash is returned as 
      binary.
   """

   # Does the file exist?
   if not arizonageneral.valid_fn(filename):
      raise IOError, (2, "No such file or directory '"+filename+"' in get_fn_signedhash_using_privatekey_fn (1)")

   # Does the privatekey file exist?
   if not arizonageneral.valid_fn(privatekey_fn):
      raise IOError, (2, "No such file or directory '"+privatekey_fn+"' in get_fn_signedhash_using_privatekey_fn (2)")

   # If they specified the type of hash then listen, otherwise use the default
   ( junk_in, the_out, the_err ) = os.popen3("openssl dgst "+get_hash_type(type_of_hash)+" -sign "+privatekey_fn+" "+filename)

   # close extraneous streams
   junk_in.close()

   # get the error output
   err_sl = arizonageneral.stream_to_sl(the_err)
   the_err.close()
   
   # Check to see if an error occured
   if not err_sl == []:
      raise TypeError, "Could not generate signed hash in get_fn_signedhash_using_privatekey_fn"
   
   # Get the hash if there isn't a problem.   It returns the whole binary data
   # hash produced on the output stream.
   hash_data = the_out.read()
   the_out.close()

   # Make sure something was returned
   assert(hash_data)

   # Make the hash into a string and return it...
   return binascii.b2a_hex(hash_data)








def verify_fn_signedhash_using_publickey_fn(filename, signedhash, publickey_fn, type_of_hash = None):
   """
   <Purpose>
      This takes a file, a signedhash (string), a file that contains a 
      publickey, and (optionally) a hash type.   It determines if the 
      given signedhash for the file was generated by the privatekey that 
      corresponds to the given publickey.   The type of publickey is not 
      taken as an argument because it is not accepted as an argument by 
      openssl.

   <Arguments>
      filename:
            The file which the hash corresponds to
      signedhash:
            The signed hash for file
      publickey_fn:
            The filename which contains the private key
      type_of_hash:
            This is the type of hash (sha1, etc.).   If the value is not 
            specified then the default is used.

   <Exceptions>
      TypeError is raised if an argument is invalid.   IOError is raised if 
      the privatekey_fn or filename is invalid or unreadable, etc.

   <Side Effects>
      None

   <Returns>
      True if the signedhash is valid or False otherwise.
   """

   
   # Check the hash argument validity
   if not isinstance(signedhash,str) and not isinstance(signedhash, unicode):
      raise TypeError, "signedhash not a string in verify_fn_signedhash_using_publickey_fn"

   # Convert the signedhash to binary and dump it to a file.    This is 
   # unfortunately necessary because openssl doesn't seem to recognize ascii 
   # hash dumps.
   (temp_signedhash_fd, temp_signedhash_fn) = tempfile.mkstemp(suffix=".verify_fn_signedhash_using_publickey.temp")
  
   try:
      os.write(temp_signedhash_fd,binascii.a2b_hex(signedhash))
      os.close(temp_signedhash_fd)
   except (IOError, OSError):
      os.remove(temp_signedhash_fn)
      raise
                                                                                

   # Now try to verify the signedhash and remove the temporary signed hash file
   try:
      ( junk_in, the_out, the_err ) = os.popen3("openssl dgst "+get_hash_type(type_of_hash)+" -signature "+temp_signedhash_fn+" -verify "+publickey_fn+" "+filename)
   except TypeError:
      print "Option 1"+temp_signedhash_fn, os.path.exists(temp_signedhash_fn)
      os.remove(temp_signedhash_fn)
      raise

   
   # Close extraneous stream
   junk_in.close()


   # Get stringlists corresponding to the out and err streams...
   out_sl = arizonageneral.stream_to_sl(the_out)
   the_out.close()
   err_sl = arizonageneral.stream_to_sl(the_err)
   the_err.close()
   
   # Remove the temporary signedhash file
   os.remove(temp_signedhash_fn)

   # If there was an error...
   if not err_sl == []:
      raise TypeError, "Error verifying signature in verify_fn_signedhash_using_publickey_fn"+ "\n".join(err_sl)

   assert(not out_sl == [])

   # If it worked then verify, else don't
   if out_sl[0].startswith("Verified OK"):
      return True
   else:
      return False




def retrieve_hash_from_signatureblock_sl(signatureblock):
   """
   <Purpose>
      This takes a signature block and returns a tuple containing the hash and
      hashtype from a signature block.

   <Arguments>
      signatureblock:
         This is the string list that contains the signature block

   <Exceptions>
      TypeError is raised if the signatureblock is not a string list or is 
      invalid.

   <Side Effects>
      None

   <Returns>
      A tuple containing the hash and hash type from a signature block.   
   """

   # Check that we have a sl
   if not valid_sl(signatureblock):
      raise TypeError, "Invalid signatureblock in retrieve_hash_from_signatureblock_sl"

   # Check that it isn't a null block
   if signatureblock == []:
      raise TypeError, "Null signatureblock in retrieve_hash_from_signatureblock_sl"
      
   # Make sure the header and footer are correct
   if signatureblock[0].startswith("-----SIGNATURE (stork 1) BEGINS-----"):
      hash_type = "-sha1"
   # new version signature
   elif signatureblock[0].startswith("<!-- -----SIGNATURE"):
      hash_type = signatureblock[0].split()[2]
   else:
      raise TypeError, "Invalid header line for signatureblock in retrieve_hash_from_signatureblock_sl"

   # Make sure there is a valid footer
   if not signatureblock[-1].startswith("-----SIGNATURE"):
      raise TypeError, "Invalid footer line for signatureblock in retrieve_hash_from_signatureblock_sl"

   # Make sure the body has some length
   if len(signatureblock)==2:
      raise TypeError, "No hash in signatureblock in retrieve_hash_from_signatureblock_sl"

   return (signatureblock[1:-1],hash_type)
   






def retrieve_signatureblock_from_sl(stringlist):
   """
   <Purpose>
      This takes a stringlist and returns a tuple containing the part before 
      the signature block and the signature block itself.   If 
      the stringlist does not have a signature block, it throws TypeError

   <Arguments>
      stringlist:
         This is the string list that contains the signature block

   <Exceptions>
      TypeError is raised if the string list does not contain a signature block
      or if the stringlist argument is not actually a string list.

   <Side Effects>
      None

   <Returns>
      A tuple containing the string list before the signature block and the 
      string list containing the signature block
   """

   # Make sure it's a string list
   if not valid_sl(stringlist):
      raise TypeError, "Invalid stringlist in retrieve_signatureblock_from_sl"
   
   # Parse through the file looking for the starting block...
   for lineno in range(len(stringlist)):
      # old school signature
      if stringlist[lineno].startswith("-----SIGNATURE (stork 1) BEGINS"):
         return (stringlist[:lineno],stringlist[lineno:])
      # new version signature
      if stringlist[lineno].startswith("<!-- -----SIGNATURE"):
         return (stringlist[:lineno],stringlist[lineno:])

   else:
      # No signature was found
      raise TypeError, "stringlist does not contain signature block in retrieve_signatureblock_from_sl"
      
         





def verify_signatureblock_using_publickey_fn(stringlist, signatureblock, publickey_fn):
   """
   <Purpose>
      This takes a string list, the corresponding signature block, and a 
      stringlist containing a publickey and returns True if the signature is
      valid or False otherwise.

   <Arguments>
      stringlist:
         This is the string list (the original message)
      signatureblock:
         This is a string list that contains the signature block (the signature)
      publickey_fn:
         This is the filename that contains the publickey

   <Exceptions>
      TypeError is raised if any argument is invalid

   <Side Effects>
      None

   <Returns>
      True if the signature is valid or False otherwise
   """

   # Make sure it's a string list
   if not valid_sl(stringlist):
      raise TypeError, "Invalid stringlist in verify_signatureblock_using_publickey_sl"
   
   # Make sure it's a string list
   if not valid_sl(signatureblock):
      raise TypeError, "Invalid signatureblock in verify_signatureblock_using_publickey_sl"
   
   # Make sure it's a valid filename
   if not arizonageneral.valid_fn(publickey_fn):
      raise TypeError, "Invalid publickey_fn in verify_signatureblock_using_publickey_sl"
   

   # Get the hash and hash type
   (signedhash, hash_type) = retrieve_hash_from_signatureblock_sl(signatureblock)
      
   # Dump the data to check to a file
   tempfile = sl_to_fn(stringlist)
   
   # Make sure to remove the tempfile (even with an error)
   try:
      # If it's valid, return True, else False
      if verify_fn_signedhash_using_publickey_fn(tempfile, "".join(signedhash), publickey_fn, type_of_hash = hash_type):
         return True
      else:
         return False
   finally:
      os.remove(tempfile)
      








def create_signatureblock_using_privatekey_fn(stringlist, privatekey_fn, type_of_hash=None):
   """
   <Purpose>
      This takes a string list and a filename containing a private key.
      It returns the signature block for the string list (signed with the
      private key).

   <Arguments>
      stringlist:
         This is the string list (the original message)
      privatekey_fn:
         This is the file that contains the private key
      type_of_hash:
         This is the type of hash function that should be used for the 
         signature

   <Exceptions>
      TypeError is raised if any argument is invalid

   <Side Effects>
      None

   <Returns>
      A string list containing the signature block
   """

   # Make sure it's a string list
   if not valid_sl(stringlist):
      raise TypeError, "Invalid stringlist in create_signatureblock_using_privatekey_fn"
   
   # Make sure it's a valid filename
   if not arizonageneral.valid_fn(privatekey_fn):
      raise TypeError, "Invalid publickey_fn in create_signatureblock_using_privatekey_fn"
   

   # Dump the sl to a tempfile
   tempfile = sl_to_fn(stringlist)

   # Get the hash and then kill the tempfile
   try:
      signedhash = get_fn_signedhash_using_privatekey_fn(tempfile, privatekey_fn, type_of_hash)
   finally:
      os.remove(tempfile)
 
   # Build the signature block
   signatureblock = [ '<!-- -----SIGNATURE '+ get_hash_type(type_of_hash=None)+' BEGINS-----', signedhash, '-----SIGNATURE '+get_hash_type(type_of_hash=None)+' ENDS----- -->']
 
   return signatureblock









def sign_file_using_privatekey_fn(filename, privatekey_fn, type_of_hash=None):
   """
   <Purpose>
      This takes a target filename and a filename containing a private key.
      It removes any existing signature block for the file and signs the 
      file with the private key.

   <Arguments>
      filename:
         This is the source file (the original message)
      privatekey_fn:
         This is the file that contains the private key
      type_of_hash:
         This is the type of hash function that should be used for the 
         signature

   <Exceptions>
      TypeError is raised if any argument is invalid

   <Side Effects>
      The given file is signed with the user's private key and existing 
      signatures are removed.

   <Returns>
      None
   """

   # Make sure it's a valid filename
   if not arizonageneral.valid_fn(filename):
      raise TypeError, "Invalid stringlist in verify_signatureblock_using_publickey_sl"
   
   # Make sure it's a valid filename
   if not arizonageneral.valid_fn(privatekey_fn):
      raise TypeError, "Invalid publickey_fn in verify_signatureblock_using_publickey_sl"
   

   # Get the basic info
   filedata = fn_to_sl(filename)


   # Get the first part of the file (if there is a signature block)
   try:
      # A signature block exists, use only raw_sl
      ( raw_sl, sig_block) = retrieve_signatureblock_from_sl(filedata)
   except TypeError:
      # No signature block exists, use the whole thing
      raw_sl = filedata
   

   # Create the signature block
   signatureblock = create_signatureblock_using_privatekey_fn(raw_sl,privatekey_fn,type_of_hash)

   # Dump the sl and sig block to a tempfile
   tempfile = sl_to_fn(raw_sl + signatureblock)

   # Overwrite the original file
   shutil.move(tempfile,filename)











########################################################
########                                        ########
########          XML signature stuff           ########
########                                        ########
########################################################


# This class parses a file that should contain a signature

class SignedFileApplication(arizonaxml.XMLApplication):
   def __init__(self):
      arizonaxml.XMLApplication.__init__(self)
      arizonaxml.CreateAttr(self, 'signedhash', None)
      arizonaxml.CreateAttr(self, 'signature_algorithm', None)
      arizonaxml.CreateAttr(self, 'timestamp', None)
      arizonaxml.CreateAttr(self, 'duration', None)
      arizonaxml.CreateAttr(self, 'file_data', '')
      arizonaxml.CreateAttr(self, 'file_data_list', [])
      arizonaxml.CreateAttr(self, 'file_encoding', None)
      arizonaxml.CreateAttr(self, 'file_tag_count', 0)

   def init_header(self, sig_alg = None, tstamp = None, dur = None, fencode = None):
      # If unset set default
      if self.signature_algorithm == None:
         self.signature_algorithm = "-sha1"
      if not sig_alg == None:
         self.signature_algorithm = sig_alg

      # If unspecified use the current time
      self.timestamp = int(time.time())
      if not tstamp == None:
         self.timestamp = tstamp 

      # If unset use the default
      if self.duration == None:
         self.duration = 0
      if not dur == None:
         self.duration = dur

      # If unset use the default
      if self.file_encoding == None:
         self.file_encoding = "native"
      if not fencode == None:
         self.file_encoding = fencode
         

   def debug_print(self):
      print 'signedhash:', self.signedhash
      print 'signature_algorithm:', self.signature_algorithm
      print 'timestamp:',self.timestamp
      print 'duration:',self.duration
      print 'file_encoding:', self.file_encoding
      print 'file_tag_count:',self.file_tag_count
      #print 'file_data:',self.file_data



   def handle_data(self,data, start, end):
      if self.file_tag_count > 0:
         try:
            # put the data into a string list. We'll join file_data_list into
            # file_data when we're done processing the file tag. This is much
            # faster than repeated string concatenation on large files.
            self.file_data_list.append(data[start:end])
         except:
            self.debug_print()
            print "'"+data[:30]+"'", start, end
            raise

   def handle_start_tag(self, tag, attrs):

      if self.file_tag_count > 0:
         if tag == "FILE":
            self.file_tag_count = self.file_tag_count + 1
	 #Duy Nguyen October 31, 2006
	 #Change: If there is an attribute error, try to continue. Cause of error not clear, but it is
	 # believed to be caused by an older version of PyXML.  Restore by removing try block.
	 try:
            self.file_data = self.file_data + self.get_raw_construct() # TODO profiler complains.. is it ok?
	 except AttributeError:
	 	pass 
         return

      if tag == "SIGNED_FILE":
         self.signedhash = attrs.get("SIGNEDHASH");
         self.signature_algorithm = attrs.get("SIGNATURE_ALGORITHM");

      elif tag == "HEADER":
         self.timestamp = attrs.get("TIMESTAMP");
         self.duration = attrs.get("DURATION");

      elif tag == "FILE":
         self.file_encoding = attrs.get("ENCODING");
         self.file_tag_count = self.file_tag_count + 1

      else:
         # Shouldn't happen if DTD is correct
         raise arizonaxml.XMLError , "invalid element: " + tag


   def handle_end_tag(self,tag):
      if tag == "FILE":
         self.file_tag_count = self.file_tag_count -1
         if self.file_tag_count == 0:
            self.file_data = self.file_data + ''.join(self.file_data_list)
            self.file_data_list = []

      if self.file_tag_count > 0:
	#Duy Nguyen - October 31, 2006
	#Change: Added try catch block. #.get_raw_construct does not exist?
         try:
           self.file_data = self.file_data + self.get_raw_construct() # TODO profiler complains.. is it ok?
         except:
           pass
         return

      if tag == "SIGNED_FILE" or tag == "FILE" or tag == "HEADER":
         return
      else:
         # Shouldn't happen if DTD is correct
         raise arizonaxml.XMLError , "invalid closing element: " + tag



   def __encoded_file_data(self):
      if self.file_encoding == "hex":
         return binascii.b2a_hex(self.file_data)
      if self.file_encoding == "escaped":
         return arizonaxml.escape(self.file_data)
      elif self.file_encoding == "native":
         return self.file_data
      else:
         raise TypeError, "Invalid file encoding type: "+self.file_encoding+" for signed file"



   def __decoded_file_data(self):
      if self.file_encoding == "hex":
         return binascii.a2b_hex(self.file_data)
      if self.file_encoding == "escaped":
         return arizonaxml.unescape(self.file_data)
      elif self.file_encoding == "native":
         return self.file_data
      else:
         raise TypeError, "Invalid file encoding type: "+self.file_encoding+" for signed file"




   def __write_protected_data(self, filefd):
      os.write(filefd,'   <HEADER TIMESTAMP="'+str(self.timestamp)+'" DURATION="'+str(self.duration)+'"/>\n')
      os.write(filefd,'   <FILE ENCODING="'+str(self.file_encoding)+'">'+self.__encoded_file_data())
      os.write(filefd,'</FILE>\n\n')


   def valid_file(self, given_fn):

      b = SignedFileApplication()
      try: 
         null_obj = file("/dev/null", "w+")
         # Throw away all of the junk output of the original parser
         arizonareport.redirect_stdout(null_obj)
         arizonareport.redirect_stderr(null_obj)
         try:
            b.__raw_read_file(given_fn)
            abc = b.file_data
            if abc == b.file_data:
               pass
         except (UnicodeDecodeError, OSError, SystemExit, TypeError, ValueError):
            return False
         else:
            return True
      finally:
         arizonareport.restore_stdout()
         arizonareport.restore_stderr()
         # Reenable output
         # JEFFRY
         pass
      


   def read_file(self, file):
      if self.valid_file(file):
         self.__raw_read_file(file)
      else:
         raise TypeError, "Invalid signed file '"+file+"'"

   def __raw_read_file(self, file):
      self.file_data= ""
      arizonaxml.XMLParse(self, arizonaconfig.get_option("xmlsigndtd"),file)
      self.timestamp = int(self.timestamp)
      self.duration = int(self.duration)
      self.decode_file_data(self.file_encoding)


   def get_signedhash(self,privatekey_fn):
      # make sure the encoding is okay
      (thistempfd,thistempname) = tempfile.mkstemp(suffix=".xml_get_hash.temp")
      try:
         os.close(thistempfd)
         self.write_file(thistempname)
      finally:
         os.remove(thistempname)

      # Find the correct secure hash for this data
      (thisfilefd,thisfilename) = tempfile.mkstemp(suffix=".xml_get_hash.temp")
      try:
         self.__write_protected_data(thisfilefd)
         os.close(thisfilefd)
         self.signedhash = get_fn_signedhash_using_privatekey_fn(thisfilename, privatekey_fn, self.signature_algorithm)
         return self.signedhash
      finally:
         os.remove(thisfilename)


   def valid_signedhash(self,publickey_fn):
      (thisfilefd,thisfilename) = tempfile.mkstemp(suffix=".xml_valid_signedhash.temp")
      try:
         self.__write_protected_data(thisfilefd)
         os.close(thisfilefd)
         return verify_fn_signedhash_using_publickey_fn(thisfilename, self.signedhash, publickey_fn, type_of_hash = self.signature_algorithm)
      finally:
         os.remove(thisfilename)



   def decode_file_data(self, encodingtype):
      self.file_encoding = encodingtype
      if self.file_encoding == "hex":
         self.file_data = binascii.a2b_hex(self.file_data)
         return
      if self.file_encoding == "escaped":
         self.file_data = arizonaxml.unescape(self.file_data)
         return
      elif self.file_encoding == "native":
         return
      else:
         raise TypeError, "Invalid file encoding type: "+self.file_encoding+" for signed file"




   def raw_write_file(self, destfile):
      
      # Get a new temp file
      (thisfilefd,thisfilename) = tempfile.mkstemp(suffix=".xml_raw_write_file.temp")
      try:

         # Write the file
         os.write(thisfilefd,'<?xml version="1.0" encoding="ISO-8859-1" standalone="yes" ?>\n\n')
         os.write(thisfilefd,'<SIGNED_FILE SIGNEDHASH="'+str(self.signedhash)+'" SIGNATURE_ALGORITHM="'+self.signature_algorithm+'">\n')
         self.__write_protected_data(thisfilefd)
         os.write(thisfilefd,'</SIGNED_FILE>\n')

         # Close the fd
         os.close(thisfilefd)
 
         shutil.copy(thisfilename, destfile)
      finally:
         try:
            os.remove(thisfilename)
         except OSError:
            pass



   def write_file(self, destfile):
      
      (thisfilefd,tmp_fn) = tempfile.mkstemp(suffix=".xml_write_file.temp")
      os.close(thisfilefd)
    
      try:
         if self.file_encoding=="native":
            try:
               self.raw_write_file(tmp_fn)
            except UnicodeDecodeError:
               pass
 
            a = SignedFileApplication()

            if a.valid_file(tmp_fn):
               a.read_file(tmp_fn)
               try:
                  if a.file_data == self.file_data:
                     pass
                  else:
                     self.file_encoding="escaped"
                     self.write_file(tmp_fn)
               except UnicodeDecodeError:
                  self.file_encoding="escaped"
                  self.write_file(tmp_fn)
                  
            else:
               self.file_encoding="escaped"
               self.write_file(tmp_fn)
                  
            shutil.copy(tmp_fn, destfile)

         elif self.file_encoding=="escaped":

            try:
               self.raw_write_file(tmp_fn)
            except UnicodeDecodeError:
               pass

            a = SignedFileApplication()

            if a.valid_file(tmp_fn):
               a.read_file(tmp_fn)
               try:
                  if a.file_data == self.file_data:
                     pass
                  else:
                     self.file_encoding="hex"
                     self.write_file(tmp_fn)
               except UnicodeDecodeError:
                  self.file_encoding="hex"
                  self.write_file(tmp_fn)
            else:
               self.file_encoding="hex"
               self.write_file(tmp_fn)

            shutil.copy(tmp_fn, destfile)

         elif self.file_encoding=="hex":

            self.raw_write_file(tmp_fn)
            shutil.copy(tmp_fn, destfile)

      finally:
         try:
            os.remove(tmp_fn)
         except OSError:
            pass


      
   def dump_file_data(self, destfile):
      (thisfilefd,thisfilename) = tempfile.mkstemp(suffix=".xml_dump_original_file.temp")
      try:
         os.write(thisfilefd,self.file_data)
         os.close(thisfilefd)
 
         shutil.copy(thisfilename, destfile)
      finally:
         try:
            os.remove(thisfilename)
         except OSError:
            pass
      

   def read_file_data(self, inputfile):
      self.file_data= ""
      thisfilefd = os.open(inputfile,os.O_RDONLY)

      cur = os.read(thisfilefd,1024)
      self.file_data = cur
      while cur != '':
         cur = os.read(thisfilefd,1024)
         self.file_data = self.file_data + cur

      os.close(thisfilefd)
      
      return self.file_data

      
      
      
   










def XML_sign_file_using_privatekey_fn(filename, privatekey_fn, type_of_hash=None, timestamp=None, duration=None, file_encoding=None):
   """
   <Purpose>
      This takes a target filename and a filename containing a private key.
      It removes any existing signature block for the file and signs the 
      file with the private key.

   <Arguments>
      filename:
         This is the source file (the original message)
      privatekey_fn:
         This is the file that contains the private key
      type_of_hash:
         This is the type of hash function that should be used for the 
         signature
      timestamp:
         This is the timestamp that should be added to the file
      duration:
         This is the timestamp that should be added to the file

   <Exceptions>
      TypeError is raised if any argument is invalid

   <Side Effects>
      The given file is signed with the user's private key and existing 
      signatures are removed.

   <Returns>
      None
   """

   # Make sure it's a valid filename
   if not arizonageneral.valid_fn(filename):
      raise TypeError, "Invalid stringlist in XML_sign_file_using_privatekey_fn"
   
   # Make sure it's a valid filename
   if not arizonageneral.valid_fn(privatekey_fn):
      raise TypeError, "Invalid privatekey_fn in XML_sign_file_using_privatekey_fn"

   if type_of_hash != None and not isinstance(type_of_hash,str):
      raise TypeError, "Invalid hash type in XML_sign_file_using_privatekey_fn"


   if timestamp != None and not isinstance(timestamp,int):
      raise TypeError, "Invalid hash type in XML_sign_file_using_privatekey_fn"

   if duration != None and not isinstance(duration, int):
      raise TypeError, "Invalid hash type in XML_sign_file_using_privatekey_fn"

   if file_encoding != None and not isinstance(file_encoding,str):
      raise TypeError, "Invalid hash type in XML_sign_file_using_privatekey_fn"

   signedfileobj = SignedFileApplication()

   signedfileobj.signature_algorithm = type_of_hash

   try:
      signedfileobj.read_file(filename)
   except TypeError:
      signedfileobj.read_file_data(filename)

   # Reset any portions of the header that need to be changed...
   signedfileobj.init_header(sig_alg = type_of_hash, tstamp = timestamp, dur = duration, fencode = file_encoding)

   signedfileobj.get_signedhash(privatekey_fn)

   signedfileobj.write_file(filename)






def XML_retrieve_originalfile_from_signedfile(signedfile_fn, dest_file=None):
   """
   <Purpose>
      This takes a filename and returns a filename containing the original
      file.

   <Arguments>
      signedfile_fn:
         This is the sigendfile
      dest_file:
         This is the file we want to put the original contents into

   <Exceptions>
      TypeError is raised if the file name is invalid or is not a valid signed
      file

   <Side Effects>
      The creation of the temp file whose name it returns

   <Returns>
      The name of a tempfile which it returns
   """

   # Make sure it's a valid filename
   if not arizonageneral.valid_fn(signedfile_fn):
      raise TypeError, "Invalid stringlist in sign_file_using_privatekey_fn"
      
   a = SignedFileApplication()

   # May throw TypeError
   a.read_file(signedfile_fn)

   (thisfilefd,thisfilename) = tempfile.mkstemp(suffix=".xml_original_file.temp")
   os.close(thisfilefd)
   a.dump_file_data(thisfilename)
   if dest_file == None:
      return thisfilename
   else:
      try:
         shutil.copy(thisfilename, dest_file)
      finally:
         try:
            os.remove(thisfilename)
         except OSError:
            pass
      return dest_file
   


def XML_timestamp_signedfile_with_publickey_fn(signedfile_fn, publickey_fn, publickey_string=None):
   """
   <Purpose>
      This takes a filename and returns the timestamp if it is correctly signed
      and timestamped/durationed or throws an exception otherwise

   <Arguments>
      signedfile_fn:
         This is the signedfile filename
      publickey_fn:
         File containing publickey to use when verifying signature. If 'None',
         then public key contained in 'publickey_string' will be used
      publickey_string:
         String representation of publickey. Ignored if publickey_fn != None.
         If both publickey_fn == None and publickey_string == None, then the
         publickey will be retrieved from the filename.

   <Exceptions>
      TypeError is thrown if an argument is invalid

   <Side Effects>
      None

   <Returns>
      The timestamp of the signed file if it is valid
   """
   if not arizonageneral.valid_fn(signedfile_fn):
      # Bad signed file name
      raise TypeError, "Signed file `" + str(signedfile_fn) + "' doesn't exist, or cannot be opened."
   
   # SMB - if no public key was given to us, then extract it from the filename
   tmp_pubkey_fn = None
   if publickey_fn == None:
      if publickey_string:
         # get a public key from the publickey_string passed in, if we have one
         pubkey = fnstring_to_publickey_sl(publickey_string)
      else:
         # otherwise, try to extract it from the filename
         pubkey = fnstring_to_publickey_sl(signedfile_fn)

      if not valid_publickey_sl(pubkey):
         raise TypeError, "File `" + str(signedfile_fn) + "': failed to extract public key."
   
      tmp_pubkey_fn = sl_to_fn(pubkey)
      publickey_fn = tmp_pubkey_fn
   
   if not arizonageneral.valid_fn(publickey_fn):
      # Bad publickey name
      raise TypeError, "Public key `" + str(publickey_fn) + "' doesn't exist, or cannot be opened."
      
   a = SignedFileApplication()

   try:
      a.read_file(signedfile_fn)
   except TypeError:
      # not a signed file
      if tmp_pubkey_fn:
         os.remove(tmp_pubkey_fn)
      raise TypeError, "Malformed signed file `" + str(signedfile_fn) + "'"

   if not a.valid_signedhash(publickey_fn):
      # Invalid signature
      if tmp_pubkey_fn:
         os.remove(tmp_pubkey_fn)
      raise TypeError, "Invalid signature for signed file `" + str(signedfile_fn) + "'"

   if tmp_pubkey_fn:
      os.remove(tmp_pubkey_fn)
      
   if not a.duration == 0:
      print "here", int(time.time()), a.timestamp, a.duration
      if int(time.time()) > a.timestamp + a.duration:
         # File expired
         raise TypeError, "Expired signed file `" + str(signedfile_fn) + "'"

   return a.timestamp

##########################################################################
##########################################################################
##########################################################################
#                                                                        #
#                                                                        #
#                            UNTESTED BELOW                              #
#                                                                        #
#                                                                        #
##########################################################################
##########################################################################
##########################################################################

def convert_ssh_to_ssl(infile, outfile):
   """This takes a SSH public key and converts it into SSL format
   """
   fileobj = file(infile,'r')
   line = fileobj.readline()
   dumpfile = file(outfile+".tmp0","w")

   line_parts = line.split()
   dumpfile.write("begin-base64 644 "+outfile+".tmp1\n")
   dumpfile.write(line_parts[1]+"\n")
   dumpfile.write("====\n")
   
   dumpfile.close()
   
   os.system("uudecode "+outfile+".tmp0")
   formatobj = file(outfile+".tmp1",'r')
   outobj = file(outfile+".tmp2",'w')

   header = formatobj.read(15)
   if header == "\x00\x00\x00\x07ssh-rsa\x00\x00\x00\x01":
      header_more = formatobj.read(5)
      if header_more !="\x23\x00\x00\x00\x81":
         arizonareport.send_error(3, "Failure in matching second part of RSA header")
         sys.exit(1)
      # Write the RSA header
      outobj.write("\x30\x81\x9d\x30\x0d\x06\x09\x2a\x86\x48\x86\xf7\x0d\x01\x01\x01\x05\x00\x03\x81\x8b\x00\x30\x81\x87\x02\x81\x81")

      # get and write the body (n,e, etc.)
      body = formatobj.read()
      outobj.write(body)

      # Write the footer...
      outobj.write("\x02\x01\x23")
      formatobj.close()
      outobj.close()

   elif header.startswith("\x00\x00\x00\x07ssh-dss\x00\x00\x00\x81"):
      # Write the DSA header
      outobj.write("\x30\x82\x01\xb7\x30\x82\x01\x2c\x06\x07\x2a\x86\x48\xce\x38\x04\x01\x30\x82\x01\x1f\x02\x81\x81")

      # get and write the body (n,e, etc.)
      body = formatobj.read()
      outobj.write(body)

      # No footer...
      formatobj.close()
      outobj.close()
      
   else:
      arizonareport.send_error(0, "Sorry, don't understand file format")
      sys.exit(1)

   # Encode the resulting file back into base 64 text...
   os.system("uuencode -m "+outfile+".tmp2 dummy_data > "+outfile+".tmp3")

   lasttemp = file(outfile+".tmp3",'r')
   finalout = file(outfile,'w')
   
   # Ignore uuencode header
   header = lasttemp.readline()
   
   # Write the correct header
   finalout.write("-----BEGIN PUBLIC KEY-----\n")
   myinput = lasttemp.readline()
   while myinput:
      if myinput.strip().strip('='):
         finalout.write(myinput)
      myinput = lasttemp.readline()
   finalout.write("-----END PUBLIC KEY-----\n")
   os.remove(outfile+".tmp0")
   os.remove(outfile+".tmp1")
   os.remove(outfile+".tmp2")
   os.remove(outfile+".tmp3")
      
