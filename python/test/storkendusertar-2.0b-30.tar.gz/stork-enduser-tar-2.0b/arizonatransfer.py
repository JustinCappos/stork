#! /usr/bin/env python

"""
Stork Project (http://www.cs.arizona.edu/stork/)
Module: arizonatransfer
Description:   Provides file transferring from host and synchronizing two
               different directories.
"""

"""arizonaconfig
   options=[["",     "--transfermethod",  "transfermethod", "append", "string", ["ftp", "http"], "program", "use this method to transfer files (default ftp, http)"],
            ["",     "--transfertempdir", "transfertempdir", "store", "string", "/tmp/stork_trans_tmp", "PATH", "use this path to save transferd files temporary (default is /tmp/stork_trans_tmp)"]]   
   includes=["$MAIN/transfer/*"]        
"""

import sys
import os.path
import arizonareport
import arizonaconfig
import securerandom
import arizonageneral
import shutil
import traceback
import arizonacrypt
import storkpackage

# metafile holds the names of files which need to sync
metafile = "metafile"

# it holds what transfer method is imported
global arizonafetch
arizonafetch = None

# indicates importing status. If init_status is -1, then no transfer module has been imported.
init_status = -1
prioritylist = []
modules_failed_install = []





def initialize_transfer_method(method):
   global arizonafetch
   global prioritylist
   global init_status
   global modules_failed_install;

   if method in modules_failed_install:
       arizonareport.send_error(2, "WARNING: method '" + method + "' previously tried to initialize and failed; skipping...") 
       arizonadetch = None
       return

   try:
      # import a certain transfer method
      # TODO possible security problem?   For example, method="nest as arizonafetch; hostile code...; #"
      exec("import transfer.arizonatransfer_" + method + " as arizonafetch")    
      
      # crazy and only way to use 'exec'   :)
      globals()['arizonafetch'] = locals()['arizonafetch']

      arizonareport.send_syslog(arizonareport.INFO, "\n" + arizonafetch.transfer_name() + " starting...")
      
      # initialize the transfer method
      try:
         arizonafetch.init_transfer_program()
      except:
         arizonareport.send_syslog(arizonareport.ERR, "getfiles(): Initializing : Initialization error.")
         arizonareport.send_error(2, "WARNING: Could not initialize " + method + " transfer...") 
         arizonafetch = None   
         return
     
      # init_status is set by index number so that it will indicate that something is imported
      init_status = prioritylist.index(method)
   # if module name doesn't exist
   except ImportError, (errno):
      modules_failed_install.append(method)
      arizonareport.send_syslog(arizonareport.ERR, "getfiles(): Initializing : Import error(" + str(errno) + ")")
      arizonafetch = None
      arizonareport.send_error(2, "WARNING: Could not import " + method + " transfer: " + str(errno)) 


      


def getfiles(host, filelist, destdir, hashcode = [""], prog_indicator=0, createhashfile=False):
   """
   <Purpose>
      This fetches files from given host, using prioritylist which holds 
      transfer methods to fetch files.
      It tries to get files by one method, and if it fails it uses next 
      possible method until it gets all files needed.
   
   <Arguments>
      host:
         'host' holds two things, a server name and download directory.
         For example, if you want to retrieve files from '/tmp/' directory
         in 'quadrus.cs.arizona.edu' server, the 'host' will be
         'quadrus.cs.arizona.edu/tmp'.
         'host' should be a string.

      filelist:
         'filelist' is a list of files which need to be retrieved.
         'filelist' should be a list of strings.

      destdir:
         'destdir' is a destination directory where retrieved files will 
         be placed. A user should have 'destdir' exist before retrieving 
         files. 'destdir' should be a string.

      hashcode:
         TODO needs documentation

      prog_indicator:
         If it is non-zero, this program will show a progress bar while
         downloading, with the given width. Default value is 0 (no
         indicator is shown).

   <Exceptions>
      None.

   <Side Effects>
      Set init_status

   <Returns>
      True or False to indicate success, and a list of downloaded files
   """

   global init_status
   global arizonafetch
   global prioritylist

   arizonareport.send_out(4, "[DEBUG] getfiles started")

   # downloaded files list
   downloaded_files = []

   # check if host is a string  
   arizonageneral.check_type_simple(host, "host", str, "arizonatransfer.getfiles")   

   # check if filelist contains only strings
   arizonageneral.check_type_stringlist(filelist, "filelist", "arizonatransfer.getfiles")  
   
   # check if destdir is a string
   arizonageneral.check_type_simple(destdir, "destdir", str, "arizonatransfer.getfiles")   
 
   # check if hash is a string
   arizonageneral.check_type_stringlist(hashcode, "hashcode", "arizonatransfer.getfiles")   
   
   # get username
   username = arizonageneral.getusername()

   # check that the destination directory exists  
   if not os.path.isdir(destdir):
      arizonareport.send_syslog(arizonareport.ERR, "\ngetfiles(): The destination directory '" + destdir + "' does not exist...   Aborting...")
      # return false and empty list
      return (False, downloaded_files)

   # transfer method list set by arizonaconfig
   prioritylist = arizonaconfig.get_option("transfermethod")

   # check the method list
   # if prioritylist is None, there's something wrong with configuration
   if prioritylist == None :
      arizonareport.send_syslog(arizonareport.ERR, "getfiles(): No transfer method was given.")
      return (False, downloaded_files)
  
   # create a temporary directory for the transfer
   arizonareport.send_out(4, "[DEBUG] getfiles creating temp dir")
   try:
      temp_dir = arizonaconfig.get_option("transfertempdir") + str(securerandom.SecureRandom().random())
   except TypeError:   
      arizonareport.send_syslog(arizonareport.ERR, "getfiles(): No transfer temp dir is given.")
      return (False, downloaded_files)

   # in the case of destdir has '/' at the end
   # last '/' should go away to make result list(downloaded_files) match
   if len(destdir) > 1 and destdir.endswith('/'):
      destdir = destdir[:len(destdir) - 1]

   # if there is empty strings in the filelist, those will be taken away   
   arizonareport.send_out(4, "[DEBUG] checking file list")
   fetch_list = __checkFileList(filelist)

   if hashcode != [""] and len(hashcode) != len(filelist):
      arizonareport.send_syslog(arizonareport.ERR, "getfiles(): The number of files given doesn't match the number of hashes given.")
      return (False, downloaded_files)

   arizonareport.send_out(4, "[DEBUG] creating directories")
   for item in fetch_list:
      if os.path.dirname(item) != "":
         os.makedirs(temp_dir + "/" + os.path.dirname(item))
         try:
            os.makedirs(destdir + "/" + os.path.dirname(item))
         # if the path already exists then pass
         except OSError, (errno, strerr):
            if errno == 17:
               pass
            
   # keep the number of the list to compare how many files are downloaded at the end.
   numoflist = len(fetch_list)

   # if prog_indicator is True, then set it as download_indicator so that it is passed in the transfer method program
   arizonareport.send_out(4, "[DEBUG] importing download_indicator")
   if (prog_indicator > 0):
      try:
         import download_indicator
         prog_indicator_module = download_indicator
         prog_indicator_module.set_width(prog_indicator)
      # if importing fails
      except ImportError:
         arizonareport.send_syslog(arizonareport.ERR, "getfiles(): Error on importing download_indicator.")
         prog_indicator_module = None      
   else:
      prog_indicator_module = None

   # if there is no file needing to be fetched
   if fetch_list == []:
      arizonareport.send_syslog(arizonareport.ERR, "getfiles(): No files needed to be downloaded.")
      return (False, downloaded_files)

   if not os.path.exists(temp_dir):      
      os.makedirs(temp_dir)
   
   # With prioritylist provided from configuration, go through transfer method list
   # until download every files requested
   arizonareport.send_out(4, "[DEBUG] prioritylist = " + str(prioritylist))
   for element in prioritylist:
      #if str(element) == "bittorrent":
      #     arizonareport.send_out(1, "["+username+"] BitTorrent is disabled in this build, skipping.")
      #     continue
   
      arizonareport.send_out(3, "[" + username + "] Attempting download via: " + str(element))
      # if no transfer method is initialized
      if init_status == -1:  
         initialize_transfer_method(element)
         
      if arizonafetch == None:
         init_status = -1
         continue

      # try to retrieve files using retrieve_files func of each module  
      #print "[DEBUG] arizonafetch.retrieve_files(", host, ",", fetch_list, ",", hashcode, ",", temp_dir, ",", prog_indicator_module, ")"
      arizonareport.send_out(3, "[" + username + "] Downloading: " + ", ".join(fetch_list))
      try:
         (check, retrieved_files) = arizonafetch.retrieve_files(host, fetch_list, hashcode, temp_dir, prog_indicator_module)
         if len(retrieved_files) > 0:
            arizonareport.send_out(3, "[" + username + "] Retrieved: " + ", ".join(retrieved_files))
         else:
            arizonareport.send_out(3, "[" + username + "] "+str(element)+" failed to retrieve any files, trying next method.")
      except:
         arizonareport.send_out(3, "[" +username+"] "+str(element)+": error: "+ str( sys.exc_info()[0] ) )
         check = False
         retrieved_files = []
      #print "[DEBUG] (arizonatransfer.py) (", check, ",", retrieved_files, ")"

      matching_hash_list = [] 
      really_retrieved_files = []
      # in case the retrieved_files has less files than the files requested, 
      # then hashcode should only contain the hashes of files that retrieved
      if hashcode != [""]:
         for index, each_file in enumerate(fetch_list):
            filename = temp_dir + "/" + each_file
            if retrieved_files.count(filename) != 0:
               really_retrieved_files.append(filename)
               matching_hash_list.append(hashcode[index])  
      else:
         really_retrieved_files = retrieved_files

      # check indicates if retrieve_files call succeeded or not
      if not check:
         arizonareport.send_syslog(arizonareport.INFO, "getfiles(): Transfer method failed.")
         # if it fails, move to the next method.
         init_status = -1  
         continue
      # now a file has been downloaded
      else :
         # if there is '*' in the fetch_list, then get every file list from host         
         # to know which files should be retrieved
         if not fetch_list.count('*') == 0:
            fetch_list = arizonafetch.__do_expand(host,'*')

         # from the list of retrieved files
         for i, thefile in enumerate(really_retrieved_files):
            hash_check_flag = 1
            # hash code is given, check the hash!!
            arizonareport.send_error(4, "[DEBUG] hashcode = " + str(hashcode))
            if hashcode == [""]:
               # TWH: don't emit this line; we already know this.
               # arizonareport.send_out(3, "[" + username + "] File doesn't have a hash: " + str(thefile))
               pass
            else:
               # First we check the metadata hash. The metadata hash relies on
               # the package managers and should work for tar and rpm packages.
               # If the metadata hash cannot be computed (the package is likely
               # not a tar or rpm), then we'll fallback to using a file hash.
               thehash = matching_hash_list[i]
               expected_hash = thehash.strip()
               actual_hash = "?"
               try:
                  # metadata hash
                  actual_hash = storkpackage.get_package_metadata_hash(thefile, createhashfile).strip()
                  arizonareport.send_error(4, "[DEBUG] arizonatransfer.getfiles: get_package_metadata_hash=" + actual_hash)
               except:
                  arizonareport.send_error(4, "[DEBUG] arizonatransfer.getfiles: get_package_metadata_hash=" + "".join(traceback.format_exception(sys.exc_info()[0], sys.exc_info()[1], sys.exc_info()[2])))
                  arizonareport.send_out(3, "[INFO] falling back to file hash for " + thefile)

                  # tar files are always hashed using the metadata hash, so it
                  # is probably a mistake that we have ended up here
                  if thefile.find(".tar.bz2"):
                      arizonareport.send_error(2, "[WARNING] using a file hash for a tar.bz2 file, which should probably use a metadata hash")

                  # couldn't compute metadata hash: fall back to file hash
                  try:
                     actual_hash = arizonacrypt.get_fn_hash(thefile, "sha1").strip()
                     arizonareport.send_error(4, "[DEBUG] arizonatransfer.getfiles: get_fn_hash=" + actual_hash)
                  except:
                     arizonareport.send_error(4, "[DEBUG] arizonatransfer.getfiles: get_fn_hash=" + "".join(traceback.format_exception(sys.exc_info()[0], sys.exc_info()[1], sys.exc_info()[2])))

               if not actual_hash == expected_hash:
                  arizonareport.send_error(2, "\n   Hash of the downloaded file " + str(thefile) + " (" + str(actual_hash) + ") did not match the expected hash (" + str(expected_hash) + ")")
                  hash_check_flag = 0
                  # SMB: Deleted some code here that retried downloads with
                  #    incorrect hashes, because we will automatically retry
                  #    them with the next transfer method.
                  # delete the file if it exists, because it has the wrong hash
                  try:
                     os.unlink(thefile)
                  except:
                     pass
   
            if hash_check_flag == 1:
               arizonareport.send_syslog(arizonareport.INFO, '\n"' + thefile.split(temp_dir + '/')[1] + '" transferred by ' + arizonafetch.transfer_name())
               # remove downloaded files from fetch_list
               fetch_list.remove(thefile.split(temp_dir + '/')[1])
   
               # remove the destination file if it already exists
               temp = thefile.rfind("/")
               if temp == -1:
                  filename = thefile
               else:
                  filename = thefile[temp:]
                     
               dest = destdir + os.path.dirname(thefile).split(temp_dir)[1] 
               try:
                  #print "[DEBUG] os.remove(", dest + filename, ")"
                  os.remove(dest + filename)               
               except:
                  pass   
               
               arizonareport.send_out(4, "[DEBUG] shutil.move(" + thefile +  ", " +  dest + ")")
               try:
                  shutil.move(thefile, dest)
               except IOError:
                  arizonareport.send_syslog(arizonareport.ERR, "getfiles(): error moving `" + thefile + "' to `" + dest + "'")
                  return (False, downloaded_files)

               if createhashfile:
                  arizonareport.send_out(4, "[DEBUG] shutil.move(" + thefile +  ".metahash, " +  dest + ")")
                  try:
                     shutil.move(thefile + ".metahash", dest)
                  except IOError:
                     pass # ignore these errors, the file isn't critical
                  
               # add downloaded files to downloaded_files
               downloaded_files.append(destdir + "/" + thefile.split(temp_dir + '/')[1])

      # check whether every file is downloaded
      if fetch_list == []:   
         arizonareport.send_syslog(arizonareport.INFO, "File = " + ", ".join(downloaded_files) + "\ntransfered")
         shutil.rmtree(temp_dir)
         return (True, downloaded_files)
      # still there are files haven't yet downloaded, so move to next method
      elif not len(downloaded_files) == numoflist:
         arizonareport.send_syslog(arizonareport.INFO, "Some files have not been downloaded yet.  Trying the next transfer method.")
         __close_transfer()
         continue			
      else:
         arizonareport.send_syslog(arizonareport.ERR, "getfiles(): " + element +
                  " file transfer has failed.  Trying the next transfer method.")
         __close_transfer()
         continue

   # after trying every transfer method
   arizonareport.send_syslog(arizonareport.ERR, "\ngetfiles(): Every transfer method has failed.\n")
   __close_transfer()
   shutil.rmtree(temp_dir)
   return (False, downloaded_files)





def sync_remote_dir(host, destdir, prog_indicator=0):
   """
   <Purpose>
      This synchronizes files between target directory in host and 
      destination directory.
   
   <Arguments>
      host:
         'host' holds two things, a server name and target directory.
         For example, if you want to retrieve files from '/tmp/' directory
         in 'quadrus.cs.arizona.edu' server, the 'host' will be
         'quadrus.cs.arizona.edu/tmp'.  'host' should be a string.  
         *** The host directory must contain a metafile ***

      destdir:
         'destdir' is a destination directory which will be synchronized.

      prog_indicator:
         If it is non-zero, this program will show a progress bar while
         downloading, with the given width. Default value is 0 (no
         indicator is shown).

   <Exceptions>
      None.

   <Side Effects>
      None

   <Returns>
      A tuple: (result, grabbed_files, all_files
      
      True or False to indicate success, a list of downloaded files, and a list
      of all files on the server.
   """

   # Grab the missing files...
   grabbed_files = []
   all_files = []
     
   # Fetch a metafile...
   # getfile will check that the validity of host, metafile, and destdir
   # if any of them is incorrect, return_value will be false
   #print "[DEBUG] getfiles(", host, ",", [metafile], ",", destdir, ")"
   (return_value, metafile_path) = getfiles(host, [metafile], destdir, prog_indicator=prog_indicator)
   #print "[DEBUG] (", return_value, ",", metafile_path, ") = getfiles(...)"
   if not return_value :
      arizonareport.send_syslog(arizonareport.ERR, 'sync_remote_dir(): Error in retrieving metafile')
      return (False, grabbed_files, all_files)

   # Open the file we just retrieved	
   arizonareport.send_out(4, "[DEBUG] opening " + os.path.join(destdir, metafile))
   try:
      dir_file = open(os.path.join(destdir, metafile))
   # if a file cannot be opened
   except IOError, (errno, strerror):
      arizonareport.send_syslog(arizonareport.ERR, "sync_remote_dir(): I/O error(" + str(errno) + "): " + str(strerror))		
      return (False, grabbed_files, all_files)

   # The list of items to retrieve...
   fetch_list = []
   # hash list for each file
   hash_list = []

   # for each line in the metafile, check to make sure the local file is okay
   # each line has two string; the first one is filename, and second one is hash
   # go through every file and check if each file exist in the destdir
   # and the hash of files in the destdir match the hash from metafile
   # if it doesn't satisfy, then add the file to fetch_list to be retrieved
   for line in dir_file:       
      # TWH: ignore blank lines
      if len(line.strip()) == 0:
         continue
      # Split the file's line into pieces
      line_dat = line.split()
      if len(line_dat) != 2:
         # invalid line in the meta file
         arizonareport.send_syslog(arizonareport.ERR, "sync_remote_dir(): The format of metafile is incorrect")         
         return (False, grabbed_files, all_files)
  
      # split a line into filename and filehash
      filename = line_dat[0]
      expectedhash = line_dat[1].strip()
      localfilename = os.path.join(destdir, filename)
      arizonareport.send_out(4, "[DEBUG] file: " + localfilename)
      arizonareport.send_out(4, "[DEBUG] expected hash: " + expectedhash)

      all_files.append(localfilename)

      # if this file has already been downloaded and checked, it will have
      # a filename.metahash file.. look for it
      if os.path.isfile(localfilename + ".metahash"):
         # open it and compare the hash
         f = open(localfilename + ".metahash")
         precomputedhash = f.read().strip()
         f.close()
         arizonareport.send_out(4, "[DEBUG] precomputed hash: " + precomputedhash)
         if precomputedhash == expectedhash:
            arizonareport.send_out(4, "[DEBUG] precomputed hash matched")
            # The hash matched so try the next file...
            continue
      
      # if a file looking for is in the destination directory
      if os.path.isfile(localfilename):
         # and if it has the same hash 
         # (we tell it to create a filename.metahash file for next time)
         actualhash = storkpackage.get_package_metadata_hash(localfilename, True)
         arizonareport.send_out(4, "[DEBUG] actual hash: " + actualhash)
         if actualhash == expectedhash:
            arizonareport.send_out(4, "[DEBUG] hash matched")
            # The hash matched so try the next file...
            continue

      # add it of the things to get
      arizonareport.send_out(4, "[DEBUG] either hash didn't match or file wasn't found")
      fetch_list.append(filename)
      hash_list.append(expectedhash)

   # if nothing needs to be downloaded
   if fetch_list == []:
      arizonareport.send_syslog(arizonareport.INFO, "\nFetched every requested file.")
   else :
      # get the files which needs to be downloaded
      (return_value, grabbed_files) = getfiles(host, fetch_list, destdir, hash_list, prog_indicator, True)
      # fails to get files from host
      if not return_value and grabbed_files == []:
         arizonareport.send_syslog(arizonareport.ERR, "sync_remote_dir(): Failed to retrieve files.")
         return (False, grabbed_files, all_files)

   # if we retrieve every file needed
   if len(fetch_list) == len(grabbed_files):
      return (True, grabbed_files, all_files)
   # if we retrieve some of files
   else:
      arizonareport.send_syslog(arizonareport.ERR, "sync_remote_dir(): Failed to retrieve all files.")
      return (False, grabbed_files, all_files)





def __checkFileList(checklist):   
   """
   <Purpose>
      This checks the given list and removes empty elements from the list.
   
   <Arguments>
      checklist:     
         The list to be checked, should contain strings.

   <Exceptions>
      None. 

   <Side Effects>
      None.

   <Returns>
      The list that empty elements are removed
   """

   # before check the elements, sort them for convenience

   # JRP - 11-3-06 we DO NOT want to sort this fixed list
   # because it will cause the filelist not to line up
   # correctly with the hashlist
   checked_list = []
   for item in checklist:
      checked_list.append(item)

   #checked_list.sort()
   
   # remove empty strings from list
   for one_str in checked_list:
      if one_str == '':
         checked_list.remove('')

   return checked_list





def __close_transfer() :
   """
   <Purpose>
      This closes the currently using transfer method
   
   <Arguments>
      None

   <Exceptions>
      None

   <Side Effects>
      set init_status as -1

   <Returns>
      None
   """

   global init_status  
   if arizonafetch != None: 
      arizonafetch.close_transfer_program()
   init_status = -1




